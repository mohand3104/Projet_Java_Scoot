package view;

import javax.swing.*;
import java.awt.*;

public class AjouterScooterView extends JFrame {

    private JTextField idField;
    private JTextField modeleField;
    private JTextField kilometrageField;
    private JTextField tarifField;
    private JTextField cautionField;
    private JComboBox<String> permisBox;
    private JButton ajouterButton;
    private JButton annulerButton;

    public AjouterScooterView() {
        setTitle("LOUSCOOT - Ajouter un Scooter");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(400, 400);
        setLocationRelativeTo(null);

        Font font = new Font("Segoe UI", Font.PLAIN, 14);

        JPanel panel = new JPanel(new GridLayout(7, 2, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        idField = new JTextField();
        modeleField = new JTextField();
        kilometrageField = new JTextField();
        tarifField = new JTextField();
        cautionField = new JTextField();
        permisBox = new JComboBox<>(new String[]{"A1", "A2"});

        ajouterButton = new JButton("Ajouter");
        annulerButton = new JButton("Annuler");

        panel.add(new JLabel("ID :"));
        panel.add(idField);
        panel.add(new JLabel("Modèle :"));
        panel.add(modeleField);
        panel.add(new JLabel("Kilométrage :"));
        panel.add(kilometrageField);
        panel.add(new JLabel("Tarif journalier :"));
        panel.add(tarifField);
        panel.add(new JLabel("Caution :"));
        panel.add(cautionField);
        panel.add(new JLabel("Permis requis :"));
        panel.add(permisBox);
        panel.add(ajouterButton);
        panel.add(annulerButton);

        add(panel);

        annulerButton.addActionListener(e -> dispose());

        setVisible(true);
    }

    public String getId() { return idField.getText(); }
    public String getModele() { return modeleField.getText(); }
    public String getKilometrage() { return kilometrageField.getText(); }
    public String getTarif() { return tarifField.getText(); }
    public String getCaution() { return cautionField.getText(); }
    public String getPermis() { return (String) permisBox.getSelectedItem(); }
    public JButton getAjouterButton() { return ajouterButton; }

    public static void main(String[] args) {
        new AjouterScooterView();
    }
}
